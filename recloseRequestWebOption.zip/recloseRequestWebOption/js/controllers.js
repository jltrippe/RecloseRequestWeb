angular.module('app.controllers', [])
  
.controller('homeCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
   
.controller('profileCtrl', ['$scope', '$stateParams', '$state', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $state) {
$scope.profile = {
	name: "Barry Allen",
	phone: "222-456-1298",
	company: "IBM",
	contractor: true,
	fcc: "Bruce Wayne"
	}

$scope.saveProfile = function () {
	$state.go("request");
}

}])
   
.controller('requestCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
   
.controller('detailsCtrl', ['$scope', '$stateParams', '$ionicPopup', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $ionicPopup) {

$scope.profile = [
	{label: "Name", value: "John Smith"},
	{label: "Phone #", value: "222-123-4567"},
	{label: "Company", value: "Oncor"},
	{label: "Contractor", value: "No"},
	{label: "Crew", value: "Transmission"}
]
$scope.form = [
	{label: "DOC", value: "WD Metro"},
	{label: "Service Area", value: "SD/DSS/USQ"},
	{label: "Substation", value: "Blue Mountain Substation"},
	{label: "Feeder", value: "9987"},
	{label: "Event #", value: "1234"},
	{label: "Starting Location", value: "FLN2342343"},
	{label: "Ending Location", value: "FLN234678"},
	{label: "Inst Relay", value: "Yes"},
	{label: "Upline Device", value: "Fuse"},
	{label: "Carry Over", value: "No"},
]

$scope.showConfirm = function() {
     var confirmPopup = $ionicPopup.confirm({
       title: 'Are you sure?',
       template: '<div class="centered">Closing the request is permanent. <br>'
       	+ ' Only continue if your work is complete.</div>',
       buttons: [
       { text: 'BACK',
   		 type: 'button-positive'},
       { text: 'CLOSE REQUEST',
         type: 'button-assertive',
         onTap: function(e) {
         	//Clear request data
         	$state.go("request");
     	}
     	}]
 });
}


$scope.showSubmitSuccess = function() {
     var confirmPopup = $ionicPopup.confirm({
       title: 'Submit Success!',
       buttons: [
       { text: 'OK',
   		 type: 'button-positive'},
       ]
 });
}

$scope.showSubmitFailure = function() {
     var confirmPopup = $ionicPopup.confirm({
       title: 'Submit Failed',
       template: '<div class="centered">Your data will remain as a draft. <br>'
       + 'Please try to submit again or call your Service Desk to open the request.',
       buttons: [
       { text: 'OK',
   		 type: 'button-positive'},
       ]
 });
}

      
}])
 